package surveyApp;

public class DataAnalyst extends User {

    public DataAnalyst(String username) {
        super(username);
    }

    // Method to generate a report based on the responses
    public void generateReport(Survey survey) {
        System.out.println("Generating report for survey: " + survey.getSurveyName());

        // Initialize an array to store the count of each answer for each question
        int[] answerCount = new int[survey.getQuestions().size()];
        //2D array of strings storing the possible answer choices for each question in the survey.
        //answerChoices[i] represents the possible answers for question i.
       // The outer array (String[][] answerChoices) corresponds to different questions.
       // The inner arrays (String[]) store the possible answer choices for each question.
       // String[][] answerChoices = new String[survey.getQuestions().size()][];

        // Prepare answer choices for each question (based on its type)
        for (int i = 0; i < survey.getQuestions().size(); i++) {
            Question q = survey.getQuestions().get(i);
            if (q instanceof MCQ) {
                answerChoices[i] = ((MCQ) q).getAnswers();  // Store answers for MCQ questions
            } else if (q instanceof TrueFalse) {
                answerChoices[i] = new String[]{"True", "False"};  // True/False options
            }
        }

        // Count responses for each question
        for (Response response : responses) {
            int questionId = response.getQuestion().getQuestionId();
            String answer = response.getAnswer();

            for (int i = 0; i < survey.getQuestions().size(); i++) {
                Question q = survey.getQuestions().get(i);
                if (q.getQuestionId() == questionId) {
                    String[] possibleAnswers = answerChoices[i];
                    // Check which answer the respondent selected
                    for (int j = 0; j < possibleAnswers.length; j++) {
                        if (possibleAnswers[j].equals(answer)) {
                            answerCount[i]++;
                            break;
                        }
                    }
                    break;
                }
            }
        }

        // Generate the report
        for (int i = 0; i < survey.getQuestions().size(); i++) {
            Question q = survey.getQuestions().get(i);
            System.out.println("Question " + q.getQuestionId() + ": " + q.getText());

            int totalResponses = responses.size();
            String[] possibleAnswers = answerChoices[i];

            for (String answer : possibleAnswers) {
                int count = 0;
                for (Response response : responses) {
                    if (response.getAnswer().equals(answer) && response.getQuestion().getQuestionId() == q.getQuestionId()) {
                        count++;
                    }
                }
                double percentage = (count / (double) totalResponses) * 100;
                System.out.println(answer + ": " + String.format("%.2f", percentage) + "% answered");
            }
        }
    }

    @Override
    public void takeSurvey(Survey survey) {
        System.out.println("Data Analyst cannot take surveys.");
    }
}
