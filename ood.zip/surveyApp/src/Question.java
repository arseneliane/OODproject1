abstract class Question {

	public Question() {
		// TODO Auto-generated constructor stub
	}

}
