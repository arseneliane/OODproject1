package surveyApp;

public class Helper {

    // Overriding the equalTo method to compare objects
    public static boolean equalTo(Object obj1, Object obj2) {
        if (obj1 == obj2) {
            return true; // Same object or both are null
        }
        
        if (obj1 == null || obj2 == null) {
            return false; // One of the objects is null
        }
        
        if (obj1.getClass() != obj2.getClass()) {
            return false; // Objects are not of the same class
        }
        
        // Comparing attributes based on class type
        if (obj1 instanceof Question) {
            Question q1 = (Question) obj1;
            Question q2 = (Question) obj2;
            return q1.getQuestionId() == q2.getQuestionId() &&
                   q1.getText().equals(q2.getText()) &&
                   q1.getQuestionType().equals(q2.getQuestionType());
        } else if (obj1 instanceof Survey) {
            Survey s1 = (Survey) obj1;
            Survey s2 = (Survey) obj2;
            return s1.getSurveyID().equals(s2.getSurveyID()) &&
                   s1.getSurveyName().equals(s2.getSurveyName()) &&
                   s1.getSurveyTheme().equals(s2.getSurveyTheme());
        } else if (obj1 instanceof User) {
            User u1 = (User) obj1;
            User u2 = (User) obj2;
            return u1.getUsername().equals(u2.getUsername());
        }
        
        return false; // Default case if the objects are of unknown type
    }

    // Overriding the toString method to provide a string representation of the object
    public static String toString(Object obj) {
        if (obj == null) {
            return "null";
        }

        if (obj instanceof Question) {
            Question q = (Question) obj;
            return "Question ID: " + q.getQuestionId() + ", Text: " + q.getText() + ", Type: " + q.getQuestionType();
        } else if (obj instanceof Survey) {
            Survey s = (Survey) obj;
            return "Survey ID: " + s.getSurveyID() + ", Name: " + s.getSurveyName() + ", Theme: " + s.getSurveyTheme();
        } else if (obj instanceof User) {
            User u = (User) obj;
            return "Username: " + u.getUsername();
        }

        return obj.toString(); // For other object types, use the default toString implementation
    }
}
