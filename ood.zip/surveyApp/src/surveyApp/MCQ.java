package surveyApp;
import java.util.*;

public class MCQ extends Question {
private int nbOfAnswers;
private String[] answers;
// Constructor
public MCQ(int questionId, String text, Survey survey, int nbOfAnswers, String[] answers) {
    super(questionId, text, "MCQ", survey);
    this.nbOfAnswers = nbOfAnswers;
    this.answers = answers;
}

//Getters and setters (optional)
public int getNbOfAnswers() {
    return nbOfAnswers;
}

public void setNbOfAnswers(int nbOfAnswers) {
    this.nbOfAnswers = nbOfAnswers;
}

public String[] getAnswers() {
    return answers;
}

public void setAnswers(String[] answers) {
    this.answers = answers;
}
//Implement displayQuestion to show details about this MCQ
@Override
public void displayQuestion() {
    System.out.println("Question ID: " + getQuestionId());
    System.out.println("Text: " + getText());
    System.out.println("Type: " + getQuestionType());
    System.out.println("Answers:");
    for (String answer : answers) {
        System.out.println("- " + answer);
    }
}
// Implement displayAllQuestions (assuming you will iterate through a collection of questions)
@Override
public void displayAllQuestions() {
    System.out.println("Displaying all MCQ questions...");
    // Could iterate over a collection of questions if available
}
}