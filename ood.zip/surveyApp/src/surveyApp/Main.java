package surveyApp;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<Survey> surveys = new ArrayList<>();
        Map<Survey, String[][]> surveyResponses = new HashMap<>(); // Store responses for each survey
        
        // Ask for user role: SurveyMaker or SurveyTaker
        String role = "";
        while (true) {
            try {
                System.out.println("Are you a SurveyMaker or SurveyTaker? (Enter 'SurveyMaker' or 'SurveyTaker')");
                role = scanner.nextLine().trim();

                if (!role.equalsIgnoreCase("SurveyMaker") && !role.equalsIgnoreCase("SurveyTaker")) {
                    throw new IllegalArgumentException("Invalid role! Please enter 'SurveyMaker' or 'SurveyTaker'.");
                }
                break;
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        }

        if (role.equalsIgnoreCase("SurveyTaker") && surveys.isEmpty()) {
            System.out.println("No surveys available. Switching to SurveyMaker...");
            role = "SurveyMaker";
        }

        if (role.equalsIgnoreCase("SurveyMaker")) {
            System.out.println("Enter your username: ");
            String username = scanner.nextLine();
            SurveyMaker maker = new SurveyMaker(username);

            System.out.println("Enter Survey Name: ");
            String surveyName = scanner.nextLine();
            System.out.println("Enter Survey ID: ");
            String surveyID = scanner.nextLine();
            System.out.println("Enter Survey Theme: ");
            String surveyTheme = scanner.nextLine();

            Survey survey = new Survey(surveyName, surveyID, surveyTheme);

            // Add questions
            while (true) {
                System.out.println("Add a Question (MCQ/TrueFalse)? Enter 'exit' to stop: ");
                String questionType = scanner.nextLine().trim();

                if (questionType.equalsIgnoreCase("exit")) {
                    break;
                }

                if (!questionType.equalsIgnoreCase("MCQ") && !questionType.equalsIgnoreCase("TrueFalse")) {
                    System.out.println("Invalid question type! Enter 'MCQ' or 'TrueFalse'.");
                    continue;
                }

                int questionId;
                while (true) {
                    System.out.println("Enter Question ID (number): ");
                    if (scanner.hasNextInt()) {
                        questionId = scanner.nextInt();
                        scanner.nextLine();
                        break;
                    } else {
                        System.out.println("Invalid input! Enter a numeric Question ID.");
                        scanner.nextLine();
                    }
                }

                System.out.println("Enter Question Text: ");
                String questionText = scanner.nextLine();

                if (questionType.equalsIgnoreCase("MCQ")) {
                    int nbOfAnswers;
                    while (true) {
                        System.out.println("Enter Number of Choices: ");
                        if (scanner.hasNextInt()) {
                            nbOfAnswers = scanner.nextInt();
                            scanner.nextLine();
                            break;
                        } else {
                            System.out.println("Invalid input! Enter a valid number.");
                            scanner.nextLine();
                        }
                    }

                    String[] answers = new String[nbOfAnswers];
                    for (int i = 0; i < nbOfAnswers; i++) {
                        System.out.println("Enter Choice " + (i + 1) + ": ");
                        answers[i] = scanner.nextLine();
                    }
                    survey.addQuestion(new MCQ(questionId, questionText, survey, nbOfAnswers, answers));
                } else {
                    survey.addQuestion(new TrueFalse(questionId, questionText, survey));
                }
            }

            surveys.add(survey);
            System.out.println("Survey Created Successfully!");

            System.out.println("How many people will take the survey?");
            int takersCount = scanner.nextInt();
            scanner.nextLine();

            String[][] answers = new String[survey.getQuestions().size()][takersCount];

            for (int i = 0; i < takersCount; i++) {
                System.out.println("Enter Survey Taker Username: ");
                String takerUsername = scanner.nextLine();
                SurveyTaker taker = new SurveyTaker(takerUsername);
                taker.takeSurvey(survey);

                for (int j = 0; j < taker.getResponses().size(); j++) {
                    answers[j][i] = taker.getResponses().get(j).getAnswer();
                }
                System.out.println("Survey responses saved!");
            }

            surveyResponses.put(survey, answers);
        }

        if (role.equalsIgnoreCase("SurveyTaker")) {
            if (surveys.isEmpty()) {
                System.out.println("No surveys available. Please ask the SurveyMaker to create one.");
                return;
            }

            int surveyChoice = -1;
            while (surveyChoice < 1 || surveyChoice > surveys.size()) {
                System.out.println("Choose a survey to take:");
                for (int i = 0; i < surveys.size(); i++) {
                    System.out.println((i + 1) + ". " + surveys.get(i).getSurveyName());
                }
                System.out.print("Enter the number of the survey: ");
                if (scanner.hasNextInt()) {
                    surveyChoice = scanner.nextInt();
                    scanner.nextLine();
                    if (surveyChoice < 1 || surveyChoice > surveys.size()) {
                        System.out.println("Invalid choice! Please select a valid survey number.");
                    }
                } else {
                    System.out.println("Invalid input! Enter a valid number.");
                    scanner.nextLine();
                }
            }

            Survey chosenSurvey = surveys.get(surveyChoice - 1);
            System.out.println("Enter Survey Taker Username: ");
            String takerUsername = scanner.nextLine();
            SurveyTaker taker = new SurveyTaker(takerUsername);
            taker.takeSurvey(chosenSurvey);

            String[][] answers = surveyResponses.getOrDefault(chosenSurvey, new String[chosenSurvey.getQuestions().size()][1]);

            for (int i = 0; i < taker.getResponses().size(); i++) {
                answers[i][0] = taker.getResponses().get(i).getAnswer();
            }

            surveyResponses.put(chosenSurvey, answers);
            System.out.println("Survey responses saved!");
        }

        System.out.println("\nGenerating Report...");
        for (Survey s : surveys) {
            System.out.println("Survey Report for: " + s.getSurveyName());
            String[][] answers = surveyResponses.get(s);
            if (answers != null) {
                for (int questionIndex = 0; questionIndex < s.getQuestions().size(); questionIndex++) {
                    Question q = s.getQuestions().get(questionIndex);
                    System.out.println("Question " + q.getQuestionId() + ": " + q.getText());
                    if (q instanceof MCQ) {
                        String[] answerChoices = ((MCQ) q).getAnswers();
                        int[] answerCounts = new int[answerChoices.length];

                        for (int i = 0; i < answers[questionIndex].length; i++) {
                            if (answers[questionIndex][i] != null) {
                                for (int j = 0; j < answerChoices.length; j++) {
                                    if (answers[questionIndex][i].equals(answerChoices[j])) {
                                        answerCounts[j]++;
                                    }
                                }
                            }
                        }

                        int totalResponses = Arrays.stream(answerCounts).sum();
                        for (int i = 0; i < answerChoices.length; i++) {
                            double percentage = totalResponses == 0 ? 0 : (answerCounts[i] * 100.0 / totalResponses);
                            System.out.println(answerChoices[i] + ": " + String.format("%.2f", percentage) + "% answered");
                        }
                    }
                }
            }
        }
        scanner.close();
    }
}

