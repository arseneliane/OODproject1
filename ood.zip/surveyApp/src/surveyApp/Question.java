package surveyApp;

public abstract class Question {
	 protected int questionId;
	 protected String text;
	 protected String questionType;	
	 protected Survey survey;  // Composition with Survey 


// Constructor
	    public Question(int questionId, String text, String questionType,Survey survey) {
	        this.questionId = questionId;
	        this.text = text;
	        this.questionType = questionType;
	        this.survey = survey;  // Associate the Question with the Survey
	    }

		// Getters
	    public int getQuestionId() {
	        return questionId;
	    }

	    public String getText() {
	        return text;
	    }

	    public String getQuestionType() {
	        return questionType;
	    }
	    public Survey getSurvey() {
	        return survey;
	    }
// Setters
	    public void setQuestionId(int questionId) {
	        this.questionId = questionId;
	    }

	    public void setText(String text) {
	        this.text = text;
	    }

	    public void setQuestionType(String questionType) {
	        this.questionType = questionType;
	    }
	    //no setSurvey since composition
 public abstract void displayQuestion();
 public abstract void displayAllQuestions();
}