package surveyApp;

public class Response {
    private Question question;
    private String answer;

    public Response(Question question, String answer) {
        this.question = question;
        this.answer = answer;
    }

    public Question getQuestion() {
        return question;
    }

    public String getAnswer() {
        return answer;
    }
}
