package surveyApp;
import java.util.*;

public class Survey {
    private String surveyName;
    private String surveyID;
    private String surveyTheme;
    private List<Question> questions;

    // Constructor
    public Survey(String surveyName, String surveyID, String surveyTheme) {
        this.surveyName = surveyName;
        this.surveyID = surveyID;
        this.surveyTheme = surveyTheme;
        this.setQuestions(new ArrayList<>()); 
    }
    //getters and setters
    public String getSurveyName() {
        return surveyName;
    }

    public void setSurveyName(String surveyName) {
        this.surveyName = surveyName;
    }

    public String getSurveyID() {
        return surveyID;
    }

    public void setSurveyID(String surveyID) {
        this.surveyID = surveyID;
    }

    public String getSurveyTheme() {
        return surveyTheme;
    }

    public void setSurveyTheme(String surveyTheme) {
        this.surveyTheme = surveyTheme;
    }
	public List<Question> getQuestions() {
		return questions;
	}
	public void setQuestions(List<Question> questions) {
		this.questions = questions;
	}
    // Method to display the survey details
    public void displaySurvey() {
        System.out.println("Survey ID: " + surveyID);
        System.out.println("Survey Name: " + surveyName);
        System.out.println("Survey Theme: " + surveyTheme);
        System.out.println("Questions:");
        for (Question q : questions) { //displayAllQuestions
            q.displayQuestion();
    }
    }
public void addQuestion(Question question) {
            questions.add(question);
        }
public void deleteQuestion(int questionId) {
            questions.removeIf(q -> q.getQuestionId() == questionId);
        }
    
/*public Question getQuestionById(int questionId) {
            for (Question q : questions) {
                if (q.getQuestionId() == questionId) {
                    return q;
                }
            }
            return null;
        }*/
public void displayAllQuestions() {
            for (Question q : questions) {
                q.displayQuestion(); 
            }
        }

}
