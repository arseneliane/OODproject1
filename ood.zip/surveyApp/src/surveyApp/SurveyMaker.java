package surveyApp;

public class SurveyMaker extends User {

    public SurveyMaker(String username) {
        super(username);
    }

    // Create a survey
    public void createSurvey(Survey survey) {
        System.out.println("Survey Created: " + survey.getSurveyName());
    }

    @Override
    public void takeSurvey(Survey survey) {
        System.out.println("Survey Maker cannot take surveys.");
    }
}
