package surveyApp;

import java.util.Scanner;

public class SurveyTaker extends User {

    public SurveyTaker(String username) {
        super(username);
    }

    @Override
    public void takeSurvey(Survey survey) {
        System.out.println("Taking Survey: " + survey.getSurveyName());
        Scanner scanner = new Scanner(System.in);
        
        for (Question q : survey.getQuestions()) {
            System.out.println("Q_ID: " + q.getQuestionId());
            System.out.println(q.getText());

            String answer = "";//initialize empty string
            //if q is of type MCQ
            if (q instanceof MCQ) {
                String[] answers = ((MCQ) q).getAnswers();
                System.out.println("Choose your answer:");
                for (int i = 0; i < answers.length; i++) {
                    System.out.println((i + 1) + ". " + answers[i]);
                }
                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume newline
                answer = answers[choice - 1];
            } else if (q instanceof TrueFalse) {
                System.out.println("Choose your answer (True/False): ");
                answer = scanner.nextLine();//of type string
            }

            // Save the answer for this question
            Response response = new Response(q, answer);
            this.responses.add(response);
            System.out.println("Answer recorded: " + answer);
        }
    }
}
