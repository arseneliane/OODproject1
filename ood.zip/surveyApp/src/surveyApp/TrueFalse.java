package surveyApp;

public class TrueFalse extends MCQ {
    // Constructor for TrueFalse class
    public TrueFalse(int questionId, String text, Survey survey) {
        // Call the parent MCQ constructor with fixed answers for True/False
        super(questionId, text, survey, 2, new String[]{"True", "False"});
    }

    @Override
    public void displayQuestion() {
        System.out.println("True/False Question ID: " + getQuestionId());
        System.out.println("Text: " + getText());
        System.out.println("Type: " + getQuestionType());
        System.out.println("Answers:");
        for (String answer : getAnswers()) {
            System.out.println("- " + answer);
        }
    }
}
