package surveyApp;

import java.util.ArrayList;
import java.util.List;

public abstract class User {
    protected String username;
    protected List<Response> responses;  // Store responses from SurveyTakers

    public User(String username) {
        this.username = username;
        this.responses = new ArrayList<>();
    }

    public String getUsername() {
        return username;
    }

    public List<Response> getResponses() {
        return responses;
    }

    // Method for users to answer questions (to be overridden by SurveyTakers)
    public abstract void takeSurvey(Survey survey);
}
